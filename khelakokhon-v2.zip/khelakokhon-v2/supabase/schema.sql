-- ═══════════════════════════════════════════════════════════════
--  খেলা কখন? v2 — Supabase schema
--  Supabase Dashboard → SQL Editor → New query → পুরোটা পেস্ট → Run
--  আবার চালালেও সমস্যা নেই (idempotent)।
--  সতর্কতা: এটা আগের v2 টেবিলগুলো (থাকলে) মুছে নতুন করে বানায়।
-- ═══════════════════════════════════════════════════════════════

-- পুরনো পরীক্ষামূলক টেবিল সরানো (আগের চেষ্টার অবশিষ্ট)
drop view  if exists leaderboard cascade;
drop view  if exists team_list cascade;
drop table if exists subscriptions cascade;
drop table if exists tournaments cascade;
drop table if exists predictions cascade;
drop table if exists user_teams cascade;
drop table if exists matches cascade;
drop table if exists teams cascade;
drop table if exists competitions cascade;
drop table if exists sync_log cascade;
-- profiles-এর কাঠামো বদলেছে, তাই এটাও নতুন করে (লগইন অ্যাকাউন্ট auth.users-এ থাকে, মুছবে না)
drop table if exists profiles cascade;

-- ── প্রতিযোগিতা ─────────────────────────────────────────────
create table competitions (
  code      text primary key,          -- PL, PD, BL1, SA, FL1, CL
  name_en   text not null,
  name_bn   text not null,
  emblem    text,
  sort      int  default 99
);

insert into competitions (code, name_en, name_bn, emblem, sort) values
  ('CL',  'UEFA Champions League', 'চ্যাম্পিয়ন্স লিগ', 'https://crests.football-data.org/CL.png',  1),
  ('PL',  'Premier League',        'প্রিমিয়ার লিগ',     'https://crests.football-data.org/PL.png',  2),
  ('PD',  'La Liga',               'লা লিগা',           'https://crests.football-data.org/PD.png',  3),
  ('BL1', 'Bundesliga',            'বুন্দেসলিগা',        'https://crests.football-data.org/BL1.png', 4),
  ('SA',  'Serie A',               'সিরি আ',            'https://crests.football-data.org/SA.png',  5),
  ('FL1', 'Ligue 1',               'লিগ আঁ',            'https://crests.football-data.org/FL1.png', 6);

-- ── দল (football-data.org-এর id-ই primary key) ───────────────
create table teams (
  id         int primary key,
  name_en    text not null,
  short_en   text,
  tla        text,
  name_bn    text,
  crest      text,
  updated_at timestamptz default now()
);

-- ── ম্যাচ ────────────────────────────────────────────────────
create table matches (
  id               int primary key,             -- football-data.org match id
  competition_code text references competitions(code),
  season           int,
  matchday         int,
  stage            text,
  group_name       text,
  utc_date         timestamptz not null,
  status           text not null,               -- SCHEDULED, TIMED, IN_PLAY, PAUSED, FINISHED, POSTPONED ...
  home_id          int,
  away_id          int,
  home_score       int,
  away_score       int,
  updated_at       timestamptz default now(),
  constraint matches_home_fk foreign key (home_id) references teams(id),
  constraint matches_away_fk foreign key (away_id) references teams(id)
);
create index matches_date_idx on matches (utc_date);
create index matches_home_idx on matches (home_id);
create index matches_away_idx on matches (away_id);

-- ── দলের তালিকা + কোন লিগের দল (অনবোর্ডিং-এ লিগ ধরে সাজাতে) ──
create view team_list with (security_invoker = true) as
select t.*,
  (select m.competition_code from matches m
    where m.home_id = t.id or m.away_id = t.id
    order by (m.competition_code = 'CL'), m.competition_code
    limit 1) as league
from teams t;
grant select on team_list to anon, authenticated;

-- ── ইউজার প্রোফাইল ───────────────────────────────────────────
create table profiles (
  id           uuid primary key references auth.users on delete cascade,
  display_name text,
  phone        text,
  email        text,
  onboarded    boolean default false,
  created_at   timestamptz default now()
);

-- ── প্রিয় ও রাইভাল দল ─────────────────────────────────────────
create table user_teams (
  user_id uuid references auth.users on delete cascade,
  team_id int  references teams(id) on delete cascade,
  kind    text not null check (kind in ('fav','rival')),
  primary key (user_id, team_id)
);

-- ── প্রেডিকশন ────────────────────────────────────────────────
create table predictions (
  user_id    uuid references auth.users on delete cascade,
  match_id   int  references matches(id) on delete cascade,
  home       int  not null check (home between 0 and 20),
  away       int  not null check (away between 0 and 20),
  points     int,                                  -- sync ফাংশন বসায়: ৩ = হুবহু, ১ = ফল ঠিক, ০ = ভুল
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  primary key (user_id, match_id)
);

-- ── সিঙ্ক লগ ──────────────────────────────────────────────────
create table sync_log (
  id      bigserial primary key,
  ran_at  timestamptz default now(),
  mode    text,
  ok      boolean,
  detail  text
);

-- ═══════════ নিরাপত্তা (Row Level Security) ═══════════
alter table competitions enable row level security;
alter table teams        enable row level security;
alter table matches      enable row level security;
alter table profiles     enable row level security;
alter table user_teams   enable row level security;
alter table predictions  enable row level security;
alter table sync_log     enable row level security;   -- কোনো policy নেই = শুধু service role

create policy "read competitions" on competitions for select using (true);
create policy "read teams"        on teams        for select using (true);
create policy "read matches"      on matches      for select using (true);

create policy "own profile read"   on profiles for select using (auth.uid() = id);
create policy "own profile update" on profiles for update using (auth.uid() = id);

create policy "own teams read"   on user_teams for select using (auth.uid() = user_id);
create policy "own teams insert" on user_teams for insert with check (auth.uid() = user_id);
create policy "own teams delete" on user_teams for delete using (auth.uid() = user_id);

create policy "own predictions read" on predictions for select using (auth.uid() = user_id);
-- কিকঅফের পর আর প্রেডিকশন দেওয়া/বদলানো যাবে না
create policy "predict before kickoff" on predictions for insert with check (
  auth.uid() = user_id
  and exists (select 1 from matches m where m.id = match_id and m.utc_date > now())
);
create policy "edit before kickoff" on predictions for update using (
  auth.uid() = user_id
  and exists (select 1 from matches m where m.id = match_id and m.utc_date > now())
);

-- ইউজার নিজে points বসাতে পারবে না
create or replace function guard_prediction_points()
returns trigger language plpgsql as $$
begin
  -- সাধারণ ইউজারের রিকোয়েস্ট (anon/authenticated) হলে points বদলানো যাবে না
  if current_user in ('authenticated', 'anon') then
    if tg_op = 'INSERT' then
      new.points := null;
    else
      new.points := old.points;
    end if;
    new.updated_at := now();
  end if;
  return new;
end $$;

create trigger predictions_guard
  before insert or update on predictions
  for each row execute function guard_prediction_points();

-- ═══════════ নতুন ইউজার এলে প্রোফাইল তৈরি ═══════════
create or replace function handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, email, display_name, phone)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'name', new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'phone'
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_user();

-- আগে থেকে থাকা ইউজারদের প্রোফাইল
insert into profiles (id, email, display_name)
select id, email, split_part(email, '@', 1) from auth.users
on conflict (id) do nothing;

-- ═══════════ পয়েন্ট হিসাব (sync ফাংশন ডাকে) ═══════════
create or replace function score_predictions()
returns int language plpgsql security definer set search_path = public as $$
declare n int;
begin
  update predictions p set points =
    case
      when p.home = m.home_score and p.away = m.away_score then 3
      when sign(p.home - p.away) = sign(m.home_score - m.away_score) then 1
      else 0
    end
  from matches m
  where m.id = p.match_id
    and m.status = 'FINISHED'
    and m.home_score is not null and m.away_score is not null;
  get diagnostics n = row_count;
  return n;
end $$;
revoke execute on function score_predictions() from public, anon, authenticated;
grant  execute on function score_predictions() to service_role;

-- ═══════════ লিডারবোর্ড (নাম আর পয়েন্ট ছাড়া কিছু দেখায় না) ═══════════
create or replace function get_leaderboard(lim int default 50)
returns table (display_name text, points bigint, exact bigint, played bigint)
language sql security definer set search_path = public stable as $$
  select coalesce(pr.display_name, 'খেলোয়াড়') as display_name,
         coalesce(sum(p.points), 0)            as points,
         count(*) filter (where p.points = 3)  as exact,
         count(p.points)                       as played
  from predictions p
  join profiles pr on pr.id = p.user_id
  group by pr.id, pr.display_name
  having count(p.points) > 0
  order by points desc, exact desc, played asc
  limit lim;
$$;
grant execute on function get_leaderboard(int) to anon, authenticated;
