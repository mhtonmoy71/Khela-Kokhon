// ═══════════════════════════════════════════════════════════════
//  /api/sync — football-data.org (ফ্রি টায়ার) থেকে সূচি ও ফল এনে Supabase-এ রাখে
//
//  ভিজিটররা কখনো সরাসরি football-data.org-এ যায় না; সবাই Supabase থেকে পড়ে।
//  তাই সাইটে যত লোকই আসুক, API কল হয় শুধু এই ফাংশন চললে।
//
//  দুই মোড:
//    /api/sync              → full: ৬টা প্রতিযোগিতার পুরো মৌসুম (৬টা কল) — দিনে একবার
//    /api/sync?mode=quick   → quick: গতকাল থেকে আগামীকালের ম্যাচ (১টা কল) — চাইলে ঘনঘন
//
//  দরকারি Environment Variables (Vercel → Settings → Environment Variables):
//    FD_KEY                     football-data.org API key
//    SUPABASE_URL               https://xxxx.supabase.co
//    SUPABASE_SERVICE_ROLE_KEY  Supabase → Settings → API → service_role (গোপন!)
//    CRON_SECRET                যেকোনো লম্বা র‍্যান্ডম লেখা
// ═══════════════════════════════════════════════════════════════
import { TEAMS_BN } from "./_teams-bn.js";

const FD = "https://api.football-data.org/v4";
export const COMPETITIONS = ["CL", "PL", "PD", "BL1", "SA", "FL1"];

const ymd = (d) => d.toISOString().slice(0, 10);

async function fdGet(path, key) {
  const r = await fetch(FD + path, { headers: { "X-Auth-Token": key } });
  if (!r.ok) throw new Error(`football-data ${path} → ${r.status} ${await r.text().catch(() => "")}`.slice(0, 300));
  return r.json();
}

function bnName(team) {
  const entry = TEAMS_BN[team.id];
  if (!entry) return null;
  const [check, bn] = entry;
  const en = `${team.name || ""} ${team.shortName || ""}`.toLowerCase();
  return en.includes(check.toLowerCase()) ? bn : null;
}

// football-data-এর ম্যাচ তালিকা → teams ও matches সারি
export function transform(fdMatches, fallbackComp) {
  const teams = new Map();
  const matches = [];
  for (const m of fdMatches) {
    const code = m.competition?.code || fallbackComp;
    if (!COMPETITIONS.includes(code)) continue;
    for (const t of [m.homeTeam, m.awayTeam]) {
      if (t && t.id && !teams.has(t.id)) {
        teams.set(t.id, {
          id: t.id,
          name_en: t.name || t.shortName || `Team ${t.id}`,
          short_en: t.shortName || t.name || null,
          tla: t.tla || null,
          name_bn: bnName(t),
          crest: t.crest || null,
          updated_at: new Date().toISOString(),
        });
      }
    }
    const ft = m.score?.fullTime || {};
    matches.push({
      id: m.id,
      competition_code: code,
      season: m.season?.startDate ? parseInt(m.season.startDate.slice(0, 4), 10) : null,
      matchday: m.matchday ?? null,
      stage: m.stage || null,
      group_name: m.group || null,
      utc_date: m.utcDate,
      status: m.status,
      home_id: m.homeTeam?.id || null,
      away_id: m.awayTeam?.id || null,
      home_score: ft.home ?? null,
      away_score: ft.away ?? null,
      updated_at: new Date().toISOString(),
    });
  }
  return { teams: [...teams.values()], matches };
}

async function sb(path, { method = "POST", body, prefer } = {}) {
  const url = process.env.SUPABASE_URL.replace(/\/$/, "") + "/rest/v1/" + path;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  const r = await fetch(url, {
    method,
    headers: {
      apikey: key,
      Authorization: `Bearer ${key}`,
      "Content-Type": "application/json",
      ...(prefer ? { Prefer: prefer } : {}),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  if (!r.ok) throw new Error(`supabase ${path} → ${r.status} ${await r.text().catch(() => "")}`.slice(0, 300));
  return r.status === 204 ? null : r.json().catch(() => null);
}

async function upsert(table, rows) {
  for (let i = 0; i < rows.length; i += 500) {
    await sb(`${table}?on_conflict=id`, {
      body: rows.slice(i, i + 500),
      prefer: "resolution=merge-duplicates,return=minimal",
    });
  }
}

export async function runSync(mode = "full") {
  const key = process.env.FD_KEY;
  if (!key) throw new Error("FD_KEY সেট করা নেই");
  let fdMatches = [];
  if (mode === "quick") {
    const now = new Date();
    const from = new Date(now.getTime() - 86400000);
    const to = new Date(now.getTime() + 86400000);
    const data = await fdGet(`/matches?dateFrom=${ymd(from)}&dateTo=${ymd(to)}`, key);
    fdMatches = data.matches || [];
  } else {
    // ৬টা কল একসঙ্গে — ফ্রি টায়ারের সীমা মিনিটে ১০টা
    const all = await Promise.all(
      COMPETITIONS.map((c) =>
        fdGet(`/competitions/${c}/matches`, key).then((d) =>
          (d.matches || []).map((m) => ({ ...m, competition: m.competition || { code: c } }))
        )
      )
    );
    fdMatches = all.flat();
  }
  const { teams, matches } = transform(fdMatches);
  await upsert("teams", teams);      // আগে দল, কারণ matches দলের id-র ওপর নির্ভর করে
  await upsert("matches", matches);
  const scored = await sb("rpc/score_predictions", { body: {} });
  return { mode, teams: teams.length, matches: matches.length, scored };
}

export default async function handler(req, res) {
  const secret = process.env.CRON_SECRET;
  const auth = req.headers?.authorization || "";
  const q = req.query || {};
  if (secret && auth !== `Bearer ${secret}` && q.secret !== secret) {
    return res.status(401).json({ ok: false, error: "unauthorized" });
  }
  const mode = q.mode === "quick" ? "quick" : "full";
  try {
    const result = await runSync(mode);
    await sb("sync_log", { body: { mode, ok: true, detail: JSON.stringify(result) }, prefer: "return=minimal" }).catch(() => {});
    return res.status(200).json({ ok: true, ...result });
  } catch (e) {
    await sb("sync_log", { body: { mode, ok: false, detail: String(e.message || e) }, prefer: "return=minimal" }).catch(() => {});
    return res.status(500).json({ ok: false, error: String(e.message || e) });
  }
}
