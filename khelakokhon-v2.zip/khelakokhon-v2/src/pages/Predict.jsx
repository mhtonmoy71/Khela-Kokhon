import { useEffect, useState } from "react";
import { useT } from "../lib/i18n.js";
import { getLeaderboard, getMatchesByIds, getTeamMatches } from "../lib/data.js";
import { num, dayLabel, dayKey, canPredict } from "../lib/format.js";
import { MatchRow, CompIcon } from "../components.jsx";

function Leaderboard({ me }) {
  const { t, lang } = useT();
  const [rows, setRows] = useState(null);
  useEffect(() => { getLeaderboard().then(setRows).catch(() => setRows([])); }, []);
  if (rows === null) return <div className="card"><div className="spin" /></div>;
  if (!rows.length) return <div className="card empty">{t("noLeaders")}</div>;
  return (
    <div className="card">
      {rows.map((r, i) => (
        <div className="lb" key={i} style={me && r.display_name === me ? { background: "var(--greenDim)" } : null}>
          <div className={"rk" + (i < 3 ? " top" : "")}>{i < 3 ? ["🥇", "🥈", "🥉"][i] : num(i + 1, lang)}</div>
          <div>
            <div style={{ fontWeight: 600 }}>{r.display_name}</div>
            <div className="sub">
              {lang === "bn" ? `${num(r.played, lang)} ম্যাচ · হুবহু ${num(r.exact, lang)}` : `${r.played} played · ${r.exact} exact`}
            </div>
          </div>
          <div className="pt">{num(r.points, lang)} <span className="sub">{t("pts")}</span></div>
        </div>
      ))}
    </div>
  );
}

function Mine({ user, preds, fav, onOpen, goProfile }) {
  const { t, lang } = useT();
  const [made, setMade] = useState(null);
  const [todo, setTodo] = useState(null);
  const ids = Object.keys(preds).map(Number);

  useEffect(() => {
    let live = true;
    getMatchesByIds(ids).then((r) => live && setMade(r.sort((a, b) => b.utc_date.localeCompare(a.utc_date)))).catch(() => live && setMade([]));
    return () => { live = false; };
  }, [ids.join(",")]);

  useEffect(() => {
    let live = true;
    getTeamMatches(fav, { upcoming: true, limit: 10 })
      .then((r) => live && setTodo(r.filter((m) => canPredict(m) && !preds[m.id]).slice(0, 5)))
      .catch(() => live && setTodo([]));
    return () => { live = false; };
  }, [fav.join(","), ids.join(",")]);

  if (!user) return (
    <div className="card empty">
      <div style={{ marginBottom: 12 }}>{t("loginToPredict")}</div>
      <button className="btn" onClick={goProfile}>{t("login")}</button>
    </div>
  );

  const total = Object.values(preds).reduce((s, p) => s + (p.points || 0), 0);
  return (
    <>
      <div className="card" style={{ display: "flex", padding: "14px 16px", gap: 16, marginBottom: 14 }}>
        <div style={{ flex: 1 }}><div className="muted" style={{ fontSize: 12.5 }}>{t("pts")}</div><div style={{ fontSize: 24, fontWeight: 700 }}>{num(total, lang)}</div></div>
        <div style={{ flex: 1 }}><div className="muted" style={{ fontSize: 12.5 }}>{lang === "bn" ? "প্রেডিকশন" : "Predictions"}</div><div style={{ fontSize: 24, fontWeight: 700 }}>{num(ids.length, lang)}</div></div>
        <div style={{ flex: 1 }}><div className="muted" style={{ fontSize: 12.5 }}>{lang === "bn" ? "হুবহু" : "Exact"}</div><div style={{ fontSize: 24, fontWeight: 700 }}>{num(Object.values(preds).filter((p) => p.points === 3).length, lang)}</div></div>
      </div>

      {todo?.length > 0 && (
        <>
          <div className="sec-h"><h2>{t("upcomingToPredict")}</h2></div>
          <div className="card" style={{ marginBottom: 14 }}>
            {todo.map((m) => <MatchRow key={m.id} m={m} onOpen={onOpen} />)}
          </div>
        </>
      )}

      <div className="sec-h"><h2>{t("myPredictions")}</h2></div>
      {made === null ? <div className="card"><div className="spin" /></div>
        : made.length === 0 ? <div className="card empty">{t("noPredictions")}</div>
        : (
          <div className="card">
            {made.map((m) => (
              <div key={m.id}>
                <div className="muted" style={{ fontSize: 11.5, padding: "8px 14px 0", display: "flex", gap: 6, alignItems: "center" }}>
                  <CompIcon c={m.competition} size={13} /> {dayLabel(dayKey(m.utc_date), lang, { short: true })}
                  <span style={{ flex: 1 }} />
                  {preds[m.id]?.points != null
                    ? <span className={"ptbadge p" + preds[m.id].points}>+{num(preds[m.id].points, lang)}</span>
                    : <span className="ptbadge">{t("pending")}</span>}
                </div>
                <MatchRow m={m} pred={preds[m.id]} onOpen={onOpen} />
              </div>
            ))}
          </div>
        )}
    </>
  );
}

export default function Predict({ user, profile, preds, fav, onOpen, goProfile }) {
  const { t } = useT();
  const [tab, setTab] = useState("mine");
  return (
    <div className="sec">
      <div className="seg" style={{ marginBottom: 12 }}>
        <button className={tab === "mine" ? "on" : ""} onClick={() => setTab("mine")}>{t("myPredictions")}</button>
        <button className={tab === "lb" ? "on" : ""} onClick={() => setTab("lb")}>{t("leaderboard")}</button>
      </div>
      <p className="muted" style={{ fontSize: 12.5, lineHeight: 1.5, marginBottom: 12 }}>{t("rules")}</p>
      {tab === "mine"
        ? <Mine user={user} preds={preds} fav={fav} onOpen={onOpen} goProfile={goProfile} />
        : <Leaderboard me={profile?.display_name} />}
    </div>
  );
}
