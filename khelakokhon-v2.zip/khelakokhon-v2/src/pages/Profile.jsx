import { useState } from "react";
import { useT } from "../lib/i18n.js";
import { signIn, signUp, signInGoogle, signOut } from "../lib/data.js";
import { Crest, teamName, SunIcon, MoonIcon } from "../components.jsx";

function AuthForm() {
  const { t } = useT();
  const [mode, setMode] = useState("signup");
  const [f, setF] = useState({ name: "", email: "", phone: "", password: "" });
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [note, setNote] = useState("");
  const up = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setErr(""); setNote("");
    if (mode === "signup") {
      if (!f.name.trim()) return setErr("নাম দাও");
      if (!/^(\+?88)?01[3-9]\d{8}$/.test(f.phone.replace(/[\s-]/g, ""))) return setErr("সঠিক মোবাইল নম্বর দাও (01XXXXXXXXX)");
      if (f.password.length < 6) return setErr("পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে");
    }
    setBusy(true);
    try {
      if (mode === "signup") {
        const r = await signUp({ ...f, name: f.name.trim(), phone: f.phone.replace(/[\s-]/g, "") });
        if (r.needsConfirm) setNote(t("checkEmail"));
      } else await signIn(f);
    } catch (e2) {
      const m = e2?.message || "";
      setErr(/invalid login/i.test(m) ? "ইমেইল বা পাসওয়ার্ড ভুল" : /registered/i.test(m) ? "এই ইমেইলে আগেই অ্যাকাউন্ট আছে — লগইন করো" : /confirm/i.test(m) ? "আগে ইমেইলের লিংকে ক্লিক করে অ্যাকাউন্ট চালু করো" : m || t("error"));
    }
    setBusy(false);
  }

  return (
    <div className="sec">
      <div className="seg" style={{ marginBottom: 16 }}>
        <button className={mode === "signup" ? "on" : ""} onClick={() => setMode("signup")}>{t("signup")}</button>
        <button className={mode === "login" ? "on" : ""} onClick={() => setMode("login")}>{t("login")}</button>
      </div>
      <form onSubmit={submit}>
        {mode === "signup" && (
          <label className="field"><span>{t("name")}</span><input value={f.name} onChange={up("name")} autoComplete="name" /></label>
        )}
        <label className="field"><span>{t("email")}</span><input type="email" required value={f.email} onChange={up("email")} autoComplete="email" /></label>
        {mode === "signup" && (
          <label className="field"><span>{t("phone")}</span><input inputMode="tel" placeholder="01XXXXXXXXX" value={f.phone} onChange={up("phone")} autoComplete="tel" /></label>
        )}
        <label className="field"><span>{t("password")}</span><input type="password" required value={f.password} onChange={up("password")} autoComplete={mode === "signup" ? "new-password" : "current-password"} /></label>
        {err && <div className="err">{err}</div>}
        {note && <div className="note">{note}</div>}
        <button className="btn block" disabled={busy}>{busy ? "…" : t(mode === "signup" ? "signup" : "login")}</button>
      </form>
      <div className="or">{t("or")}</div>
      <button className="btn ghost block" onClick={() => signInGoogle().catch((e) => setErr(e.message))}>
        <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="m6.3 14.7 6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>
        {t("google")}
      </button>
    </div>
  );
}

export default function Profile({ user, profile, myTeams, teamsById, lang, setLang, theme, setTheme, onEditTeams }) {
  const { t } = useT();
  const settings = (
    <div className="sec">
      <div className="sec-h"><h2>{t("settings")}</h2></div>
      <div className="card">
        <div className="kv" style={{ borderTop: 0 }}>{t("language")}
          <div className="seg" style={{ width: 150 }}>
            <button className={lang === "bn" ? "on" : ""} onClick={() => setLang("bn")}>বাংলা</button>
            <button className={lang === "en" ? "on" : ""} onClick={() => setLang("en")}>EN</button>
          </div>
        </div>
        <div className="kv">{t("theme")}
          <div className="seg" style={{ width: 150 }}>
            <button className={theme === "dark" ? "on" : ""} onClick={() => setTheme("dark")}><MoonIcon width={14} height={14} style={{ verticalAlign: -2 }} /> {t("dark")}</button>
            <button className={theme === "light" ? "on" : ""} onClick={() => setTheme("light")}><SunIcon width={14} height={14} style={{ verticalAlign: -2 }} /> {t("light")}</button>
          </div>
        </div>
      </div>
    </div>
  );

  if (!user) return <>{<AuthForm />}{settings}</>;

  const name = profile?.display_name || user.email;
  const chips = (ids) => ids.map((id) => teamsById[id]).filter(Boolean).map((tm) => (
    <span className="tchip" key={tm.id}><Crest team={tm} size={18} />{teamName(tm, lang)}</span>
  ));
  return (
    <>
      <div className="sec">
        <div className="card">
          <div className="prof-head">
            <div className="avatar">{name.slice(0, 1).toUpperCase()}</div>
            <div style={{ minWidth: 0 }}>
              <div style={{ fontWeight: 700, fontSize: 17 }}>{name}</div>
              <div className="muted" style={{ fontSize: 13 }}>{user.email}</div>
              {profile?.phone && <div className="muted" style={{ fontSize: 13 }}>{profile.phone}</div>}
            </div>
          </div>
        </div>
      </div>
      <div className="sec">
        <div className="sec-h"><h2>{t("myTeams")}</h2><button className="link" onClick={onEditTeams}>{t("edit")}</button></div>
        <div className="card" style={{ paddingTop: 12 }}>
          <div className="muted" style={{ fontSize: 12.5, padding: "0 16px 6px" }}>★ {t("favs")}</div>
          <div className="team-chips">{myTeams.fav.length ? chips(myTeams.fav) : <span className="muted" style={{ fontSize: 13 }}>—</span>}</div>
          <div className="muted" style={{ fontSize: 12.5, padding: "0 16px 6px" }}>⚔ {t("rivals")}</div>
          <div className="team-chips">{myTeams.rival.length ? chips(myTeams.rival) : <span className="muted" style={{ fontSize: 13 }}>—</span>}</div>
        </div>
      </div>
      {settings}
      <div className="sec">
        <button className="btn ghost block" onClick={signOut}>{t("logout")}</button>
      </div>
    </>
  );
}
