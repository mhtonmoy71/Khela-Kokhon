import { useEffect, useRef, useState } from "react";
import { useT } from "../lib/i18n.js";
import { getMatchesOnDay } from "../lib/data.js";
import { dayKey, addDays, stripLabel, dayLabel } from "../lib/format.js";
import { CompGroups, CompIcon, compName } from "../components.jsx";

export default function Matches({ comps, preds, onOpen }) {
  const { t, lang } = useT();
  const today = dayKey(new Date());
  const [day, setDay] = useState(today);
  const [comp, setComp] = useState("ALL");
  const [list, setList] = useState(null);
  const stripRef = useRef(null);
  const days = Array.from({ length: 22 }, (_, i) => addDays(today, i - 7));

  useEffect(() => {
    const el = stripRef.current?.querySelector(".day.on");
    el?.scrollIntoView({ inline: "center", block: "nearest" });
  }, [day]);

  useEffect(() => {
    let live = true;
    setList(null);
    getMatchesOnDay(day).then((r) => live && setList(r)).catch(() => live && setList([]));
    return () => { live = false; };
  }, [day]);

  const shown = (list || []).filter((m) => comp === "ALL" || m.competition_code === comp);

  return (
    <>
      <div className="strip" ref={stripRef}>
        {days.map((k) => {
          const l = stripLabel(k, lang);
          return (
            <button key={k} className={"day" + (k === day ? " on" : "")} onClick={() => setDay(k)}>
              <div className="a">{l.top}</div>
              <div className="b">{l.bottom}</div>
            </button>
          );
        })}
      </div>
      <div className="chips">
        <button className={"chip" + (comp === "ALL" ? " on" : "")} onClick={() => setComp("ALL")}>{t("all")}</button>
        {comps.map((c) => (
          <button key={c.code} className={"chip" + (comp === c.code ? " on" : "")} onClick={() => setComp(c.code)}>
            <CompIcon c={c} size={16} />{compName(c, lang)}
          </button>
        ))}
      </div>
      <div className="sec">
        <div className="sec-h"><h2>{dayLabel(day, lang)}</h2></div>
        {list === null ? <div className="card"><div className="spin" /></div>
          : shown.length === 0 ? <div className="card empty">{t("noMatchDay")}</div>
          : <CompGroups matches={shown} preds={preds} onOpen={onOpen} />}
      </div>
    </>
  );
}
