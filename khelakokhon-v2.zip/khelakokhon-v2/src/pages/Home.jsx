import { useEffect, useState } from "react";
import { useT } from "../lib/i18n.js";
import { getTeamMatches, getMatchesOnDay } from "../lib/data.js";
import { num, timeLabel, dayLabel, dayKey, countdown, isLive } from "../lib/format.js";
import { Crest, CompIcon, CompGroups, MatchRow, teamName, compName, useNow, Logo } from "../components.jsx";

function NextHero({ m, onOpen }) {
  const { t, lang } = useT();
  const now = useNow(30000);
  const live = isLive(m);
  return (
    <button className="hero" style={{ width: "100%", textAlign: "inherit" }} onClick={() => onOpen(m)}>
      <div className="hero-top"><CompIcon c={m.competition} size={16} />{compName(m.competition, lang)}</div>
      <div className="hero-teams">
        <div className="hero-team"><Crest team={m.home} size={60} />{teamName(m.home, lang)}</div>
        <div className="hero-vs">
          {live && m.home_score != null
            ? <div style={{ fontFamily: "Inter", fontSize: 30, fontWeight: 800 }}>{num(m.home_score, lang)} - {num(m.away_score, lang)}</div>
            : t("vs")}
        </div>
        <div className="hero-team"><Crest team={m.away} size={60} />{teamName(m.away, lang)}</div>
      </div>
      <div className="hero-time">
        <div className="big">{timeLabel(m.utc_date, lang)}</div>
        <div className="when">{dayLabel(dayKey(m.utc_date), lang)} · {t("bdTime")}</div>
      </div>
      <div className="cd">
        {live
          ? <span><i className="dot" />{t("live")}</span>
          : <span>{t("startsIn")} <b>{countdown(new Date(m.utc_date) - now, lang)}</b></span>}
      </div>
    </button>
  );
}

function resultFor(m, teamId) {
  const mine = m.home_id === teamId ? m.home_score : m.away_score;
  const theirs = m.home_id === teamId ? m.away_score : m.home_score;
  return mine > theirs ? "W" : mine < theirs ? "L" : "D";
}
const RES_BN = { W: "জ", D: "ড", L: "হ" };

function RivalWatch({ rivals, teamsById, onOpen }) {
  const { t, lang } = useT();
  const [data, setData] = useState(null);
  useEffect(() => {
    let live = true;
    Promise.all([getTeamMatches(rivals, { upcoming: false, limit: 20 }), getTeamMatches(rivals, { upcoming: true, limit: 30 })])
      .then(([past, next]) => live && setData({ past, next }))
      .catch(() => live && setData({ past: [], next: [] }));
    return () => { live = false; };
  }, [rivals.join(",")]);
  if (!data) return <div className="card"><div className="spin" /></div>;
  return (
    <div className="card">
      {rivals.map((id) => {
        const last = data.past.find((m) => m.home_id === id || m.away_id === id);
        const next = data.next.find((m) => m.home_id === id || m.away_id === id);
        const team = last ? (last.home_id === id ? last.home : last.away) : next ? (next.home_id === id ? next.home : next.away) : teamsById[id];
        const r = last && resultFor(last, id);
        const opp = last && (last.home_id === id ? last.away : last.home);
        return (
          <button className="rival" key={id} style={{ width: "100%", textAlign: "inherit" }} onClick={() => (last || next) && onOpen(last || next)}>
            <Crest team={team} size={26} />
            <div className="nm">
              {teamName(team, lang)}
              <div className="res" style={{ textAlign: "left", fontWeight: 400 }}>
                {next ? `${t("next2")}: ${teamName(next.home_id === id ? next.away : next.home, lang)} · ${dayLabel(dayKey(next.utc_date), lang, { short: true })}` : t("noUpcoming")}
              </div>
            </div>
            {last && (
              <div className="res">
                {num(last.home_id === id ? last.home_score : last.away_score, lang)}-{num(last.home_id === id ? last.away_score : last.home_score, lang)}{" "}
                {lang === "bn" ? "বনাম" : "vs"} {teamName(opp, lang)}
              </div>
            )}
            {r && <span className={"badge " + r}>{lang === "bn" ? RES_BN[r] : r}</span>}
          </button>
        );
      })}
    </div>
  );
}

export default function Home({ user, myTeams, teamsById, preds, onOpen, goProfile, goMatches }) {
  const { t, lang } = useT();
  const [mine, setMine] = useState(null);
  const [today, setToday] = useState(null);
  const fav = myTeams?.fav || [];
  const rival = myTeams?.rival || [];

  useEffect(() => {
    let live = true;
    getMatchesOnDay(dayKey(new Date())).then((r) => live && setToday(r)).catch(() => live && setToday([]));
    return () => { live = false; };
  }, []);

  useEffect(() => {
    let live = true;
    if (!fav.length) { setMine([]); return; }
    getTeamMatches(fav, { upcoming: true, limit: 8 }).then((r) => live && setMine(r)).catch(() => live && setMine([]));
    return () => { live = false; };
  }, [fav.join(",")]);

  const hero = mine?.[0];
  return (
    <>
      {fav.length === 0 ? (
        <div className="sec">
          <div className="card cta">
            <Logo size={46} />
            <div style={{ flex: 1 }}>
              <h3>{t("ctaTitle")}</h3>
              <p>{t("ctaBody")}</p>
              <button className="btn" style={{ marginTop: 12, height: 40 }} onClick={goProfile}>{t("ctaBtn")}</button>
            </div>
          </div>
        </div>
      ) : (
        <>
          <div className="sec">
            <div className="sec-h"><h2>{t("nextMatch")}</h2></div>
            {mine === null ? <div className="card"><div className="spin" /></div>
              : hero ? <NextHero m={hero} onOpen={onOpen} />
              : <div className="card empty">{t("noUpcoming")}</div>}
          </div>
          {mine?.length > 1 && (
            <div className="sec">
              <div className="sec-h"><h2>{t("yourTeams")}</h2></div>
              <div className="card">
                {mine.slice(1, 6).map((m) => (
                  <div key={m.id}>
                    <div className="muted" style={{ fontSize: 11.5, padding: "8px 14px 0", display: "flex", gap: 6, alignItems: "center" }}>
                      <CompIcon c={m.competition} size={13} /> {dayLabel(dayKey(m.utc_date), lang, { short: true })}
                    </div>
                    <MatchRow m={m} pred={preds[m.id]} onOpen={onOpen} />
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {rival.length > 0 && (
        <div className="sec">
          <div className="sec-h"><h2>{t("rivalWatch")}</h2></div>
          <RivalWatch rivals={rival} teamsById={teamsById} onOpen={onOpen} />
        </div>
      )}

      <div className="sec">
        <div className="sec-h">
          <h2>{t("todayBig")} {today?.length ? <span className="muted" style={{ fontWeight: 500 }}>({num(today.length, lang)})</span> : null}</h2>
          <button className="link" onClick={goMatches}>{t("seeAll")} →</button>
        </div>
        {today === null ? <div className="card"><div className="spin" /></div>
          : today.length === 0 ? <div className="card empty">{t("noMatchDay")}</div>
          : <CompGroups matches={today} preds={preds} onOpen={onOpen} />}
      </div>
    </>
  );
}
