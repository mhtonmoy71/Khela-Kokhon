import { useEffect, useMemo, useState } from "react";
import { useT } from "../lib/i18n.js";
import { getTeams } from "../lib/data.js";
import { num } from "../lib/format.js";
import { Crest, CompIcon, compName, teamName } from "../components.jsx";

const MAX = { fav: 3, rival: 5 };

// প্রিয় (সর্বোচ্চ ৩) আর রাইভাল (সর্বোচ্চ ৫) দল বাছাই। ফোন নম্বর না থাকলে আগে সেটা চায়।
export default function Onboarding({ initial, comps, needPhone, onDone, onCancel }) {
  const { t, lang } = useT();
  const [step, setStep] = useState(needPhone ? "phone" : "fav");
  const [phone, setPhone] = useState("");
  const [fav, setFav] = useState(initial?.fav || []);
  const [rival, setRival] = useState(initial?.rival || []);
  const [teams, setTeams] = useState(null);
  const [q, setQ] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => { getTeams().then(setTeams).catch(() => setTeams([])); }, []);

  const groups = useMemo(() => {
    const s = q.trim().toLowerCase();
    const list = (teams || []).filter((tm) => !s || [tm.name_bn, tm.name_en, tm.short_en, tm.tla].some((x) => x?.toLowerCase().includes(s)));
    return comps
      .map((c) => ({ c, list: list.filter((tm) => (tm.league || "CL") === c.code).sort((a, b) => teamName(a, lang).localeCompare(teamName(b, lang))) }))
      .filter((g) => g.list.length);
  }, [teams, q, comps, lang]);

  const kind = step === "rival" ? "rival" : "fav";
  const sel = kind === "fav" ? fav : rival;
  const setSel = kind === "fav" ? setFav : setRival;
  const other = kind === "fav" ? rival : fav;

  function toggle(id) {
    if (sel.includes(id)) setSel(sel.filter((x) => x !== id));
    else if (sel.length < MAX[kind]) setSel([...sel, id]);
  }

  async function finish() {
    setBusy(true); setErr("");
    try { await onDone({ fav, rival, phone: phone.trim() || undefined }); }
    catch (e) { setErr(e?.message || t("error")); setBusy(false); }
  }

  if (step === "phone") {
    const valid = /^(\+?88)?01[3-9]\d{8}$/.test(phone.replace(/[\s-]/g, ""));
    return (
      <div className="sec">
        <h2 style={{ fontSize: 20, marginBottom: 14 }}>{t("phoneNeeded")}</h2>
        <label className="field"><span>{t("phone")}</span>
          <input inputMode="tel" placeholder="01XXXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
        <button className="btn block" disabled={!valid} onClick={() => setStep("fav")}>{t("next")}</button>
      </div>
    );
  }

  return (
    <div className="sec">
      <h2 style={{ fontSize: 20 }}>{t(kind === "fav" ? "pickFav" : "pickRival")}</h2>
      <p className="muted" style={{ fontSize: 13.5, margin: "4px 0 12px" }}>
        {t(kind === "fav" ? "pickFavSub" : "pickRivalSub")} · {num(sel.length, lang)}/{num(MAX[kind], lang)}
      </p>
      <label className="field" style={{ marginBottom: 4 }}>
        <input placeholder={"🔍 " + t("search")} value={q} onChange={(e) => setQ(e.target.value)} />
      </label>

      {teams === null && <div className="spin" />}
      {groups.map((g) => (
        <div key={g.c.code}>
          <div className="lg-h"><CompIcon c={g.c} size={16} />{compName(g.c, lang)}</div>
          <div className="team-grid">
            {g.list.map((tm) => {
              const on = sel.includes(tm.id);
              const taken = other.includes(tm.id);
              return (
                <button key={tm.id} className={"team-pick" + (on ? " " + kind : "")} disabled={taken || (!on && sel.length >= MAX[kind])} onClick={() => toggle(tm.id)}>
                  {on && <span className="mark">{kind === "fav" ? "★" : "⚔"}</span>}
                  <Crest team={tm} size={36} />
                  {teamName(tm, lang)}
                </button>
              );
            })}
          </div>
        </div>
      ))}

      {err && <div className="err">{err}</div>}
      <div className="sticky-foot">
        {kind === "fav"
          ? <button className="btn ghost" onClick={onCancel}>{t("skip")}</button>
          : <button className="btn ghost" onClick={() => setStep("fav")}>{t("back")}</button>}
        {kind === "fav"
          ? <button className="btn" style={{ flex: 1 }} onClick={() => { setQ(""); setStep("rival"); window.scrollTo(0, 0); }}>{t("next")}</button>
          : <button className="btn" style={{ flex: 1 }} disabled={busy} onClick={finish}>{busy ? "…" : t("done")}</button>}
      </div>
    </div>
  );
}
