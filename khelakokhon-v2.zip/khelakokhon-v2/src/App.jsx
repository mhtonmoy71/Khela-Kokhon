import { useCallback, useEffect, useState } from "react";
import { LangCtx, useT } from "./lib/i18n.js";
import {
  DEMO, getCompetitions, getTeams, getUser, onAuth, getProfile, updateProfile,
  getMyTeams, saveMyTeams, getMyPredictions, savePrediction,
} from "./lib/data.js";
import { Logo, MatchSheet, HomeIcon, BallIcon, TargetIcon, UserIcon, SunIcon, MoonIcon } from "./components.jsx";
import Home from "./pages/Home.jsx";
import Matches from "./pages/Matches.jsx";
import Predict from "./pages/Predict.jsx";
import Profile from "./pages/Profile.jsx";
import Onboarding from "./pages/Onboarding.jsx";

const TABS = [
  { id: "home", path: "/", Icon: HomeIcon },
  { id: "matches", path: "/matches", Icon: BallIcon },
  { id: "predict", path: "/predict", Icon: TargetIcon },
  { id: "profile", path: "/profile", Icon: UserIcon },
];
const tabFromPath = () => TABS.find((x) => x.path === window.location.pathname)?.id || "home";
const stored = (k, d) => { try { return localStorage.getItem(k) || d; } catch { return d; } };
const store = (k, v) => { try { localStorage.setItem(k, v); } catch { /* ignore */ } };

function Nav({ tab, go }) {
  const { t } = useT();
  return (
    <nav className="nav">
      <div className="nav-in">
        {TABS.map(({ id, Icon }) => (
          <button key={id} className={tab === id ? "on" : ""} onClick={() => go(id)}>
            <Icon />{t(id)}
          </button>
        ))}
      </div>
    </nav>
  );
}

export default function App() {
  const [lang, setLangS] = useState(() => stored("kk_lang", "bn"));
  const [theme, setThemeS] = useState(() => stored("kk_theme", "dark"));
  const [tab, setTab] = useState(tabFromPath);
  const [comps, setComps] = useState([]);
  const [teamsById, setTeamsById] = useState({});
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [myTeams, setMyTeams] = useState({ fav: [], rival: [] });
  const [preds, setPreds] = useState({});
  const [sheet, setSheet] = useState(null);
  const [editing, setEditing] = useState(false);
  const [toastMsg, setToastMsg] = useState("");

  const setLang = (v) => { setLangS(v); store("kk_lang", v); };
  const setTheme = (v) => { setThemeS(v); store("kk_theme", v); };
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    document.querySelector('meta[name="theme-color"]')?.setAttribute("content", theme === "dark" ? "#0c1311" : "#eef2f1");
  }, [theme]);
  useEffect(() => { document.documentElement.lang = lang; }, [lang]);

  const toast = useCallback((m) => { setToastMsg(m); setTimeout(() => setToastMsg(""), 2200); }, []);

  // ── ট্যাব আর ফোনের ব্যাক বাটন ──
  const go = (id) => {
    const p = TABS.find((x) => x.id === id).path;
    if (window.location.pathname !== p) window.history.pushState({}, "", p);
    setTab(id); setEditing(false); window.scrollTo(0, 0);
  };
  useEffect(() => {
    const onPop = () => { setSheet(null); setTab(tabFromPath()); };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);
  const openMatch = (m) => { window.history.pushState({ sheet: 1 }, ""); setSheet(m); };
  const closeMatch = () => { if (window.history.state?.sheet) window.history.back(); else setSheet(null); };

  // ── সাধারণ ডেটা ──
  useEffect(() => {
    getCompetitions().then(setComps).catch(() => {});
    getTeams().then((ts) => setTeamsById(Object.fromEntries(ts.map((x) => [x.id, x])))).catch(() => {});
  }, []);

  // ── লগইন ──
  useEffect(() => {
    getUser().then(setUser);
    return onAuth(setUser);
  }, []);
  useEffect(() => {
    if (!user) { setProfile(null); setMyTeams({ fav: [], rival: [] }); setPreds({}); return; }
    getProfile(user).then(setProfile).catch(() => {});
    getMyTeams(user).then(setMyTeams).catch(() => {});
    getMyPredictions(user).then(setPreds).catch(() => {});
  }, [user?.id]);

  const onboarding = user && profile && (!profile.onboarded || editing);

  async function finishOnboarding({ fav, rival, phone }) {
    await saveMyTeams(user, { fav, rival });
    const p = await updateProfile(user, { onboarded: true, ...(phone ? { phone } : {}) });
    setProfile(p); setMyTeams({ fav, rival }); setEditing(false);
    go("home");
  }
  async function skipOnboarding() {
    const p = await updateProfile(user, { onboarded: true }).catch(() => profile);
    setProfile(p); setEditing(false);
  }

  async function onSavePrediction(m, h, a) {
    const p = await savePrediction(user, m.id, h, a);
    setPreds((x) => ({ ...x, [m.id]: p }));
  }

  return (
    <LangCtx.Provider value={lang}>
      <div className="app">
        <header className="top">
          <button className="brand" onClick={() => go("home")}><Logo size={30} /><span>খেলা কখন<b>?</b></span></button>
          <div className="sp" />
          <button className="pill-btn" onClick={() => setLang(lang === "bn" ? "en" : "bn")}>{lang === "bn" ? "EN" : "বাং"}</button>
          <button className="pill-btn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="theme">
            {theme === "dark" ? <SunIcon width={16} height={16} /> : <MoonIcon width={16} height={16} />}
          </button>
        </header>
        {DEMO && <div className="demo-bar">{lang === "bn" ? "ডেমো মোড — নমুনা ডেটা দেখানো হচ্ছে" : "Demo mode — sample data"}</div>}

        {onboarding ? (
          <Onboarding
            key={editing ? "edit" : "first"}
            initial={myTeams}
            comps={comps}
            needPhone={!profile.phone}
            onDone={finishOnboarding}
            onCancel={editing ? () => setEditing(false) : skipOnboarding}
          />
        ) : tab === "home" ? (
          <Home user={user} myTeams={myTeams} teamsById={teamsById} preds={preds} onOpen={openMatch} goProfile={() => go("profile")} goMatches={() => go("matches")} />
        ) : tab === "matches" ? (
          <Matches comps={comps} preds={preds} onOpen={openMatch} />
        ) : tab === "predict" ? (
          <Predict user={user} profile={profile} preds={preds} fav={myTeams.fav} onOpen={openMatch} goProfile={() => go("profile")} />
        ) : (
          <Profile user={user} profile={profile} myTeams={myTeams} teamsById={teamsById} lang={lang} setLang={setLang} theme={theme} setTheme={setTheme} onEditTeams={() => { setEditing(true); window.scrollTo(0, 0); }} />
        )}

        <div style={{ textAlign: "center", fontSize: 11.5, padding: "28px 16px 8px" }} className="muted">
          খেলা কখন? · khelakokhon.com
        </div>
      </div>

      {!onboarding && <Nav tab={tab} go={go} />}
      {sheet && (
        <MatchSheet
          key={sheet.id}
          m={sheet} user={user} pred={preds[sheet.id]} toast={toast}
          onClose={closeMatch}
          onSave={onSavePrediction}
          onLogin={() => { setSheet(null); go("profile"); }}
        />
      )}
      {toastMsg && <div className="toast">{toastMsg}</div>}
    </LangCtx.Provider>
  );
}
