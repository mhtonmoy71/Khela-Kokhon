import { useEffect, useState } from "react";
import { useT } from "./lib/i18n.js";
import { num, timeLabel, dayLabel, dayKey, countdown, isLive, isDone, isOff, canPredict } from "./lib/format.js";

export const teamName = (team, lang) =>
  !team ? (lang === "bn" ? "নির্ধারিত হয়নি" : "TBD") : lang === "bn" ? team.name_bn || team.short_en || team.name_en : team.short_en || team.name_en;
export const compName = (c, lang) => (c ? (lang === "bn" ? c.name_bn : c.name_en) : "");

// ── লোগো (আগের ঘড়ির লোগো) ──
export function Logo({ size = 30 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 80 80" aria-hidden="true">
      <circle cx="40" cy="40" r="38" fill="#064e3b" stroke="#00e676" strokeWidth="3" />
      {[[40, 4, 40, 12], [76, 40, 68, 40], [4, 40, 12, 40], [40, 76, 40, 68]].map(([a, b, c, d], i) => (
        <line key={i} x1={a} y1={b} x2={c} y2={d} stroke="rgba(255,255,255,.5)" strokeWidth="2.5" />
      ))}
      <line x1="40" y1="40" x2="40" y2="24" stroke="#fff" strokeWidth="5" strokeLinecap="round" />
      <line x1="40" y1="40" x2="55" y2="32" stroke="#00e676" strokeWidth="3" strokeLinecap="round" />
      <circle cx="40" cy="40" r="3" fill="#e11d48" />
    </svg>
  );
}

// ── দলের ক্রেস্ট (ছবি না এলে সংক্ষিপ্ত নাম) ──
export function Crest({ team, size = 22 }) {
  const [bad, setBad] = useState(false);
  if (!team?.crest || bad)
    return (
      <span className="crest-fb" style={{ width: size, height: size, fontSize: size * 0.34 }}>
        {(team?.tla || team?.short_en || "?").slice(0, 3)}
      </span>
    );
  return <img className="crest" src={team.crest} alt="" width={size} height={size} loading="lazy" onError={() => setBad(true)} />;
}

export function CompIcon({ c, size = 18 }) {
  const [bad, setBad] = useState(false);
  if (!c?.emblem || bad) return null;
  return <img src={c.emblem} alt="" width={size} height={size} onError={() => setBad(true)} />;
}

// ── স্ট্যাটাস লেখা ──
export function StatusText({ m }) {
  const { t } = useT();
  if (m.status === "PAUSED") return <span className="lv">{t("ht")}</span>;
  if (isLive(m)) return <span className="lv"><i className="dot" />{t("live")}</span>;
  if (isDone(m)) return <>{t("ft")}</>;
  if (m.status === "POSTPONED") return <>{t("postponed")}</>;
  if (m.status === "CANCELLED") return <>{t("cancelled")}</>;
  return null;
}

// ── ম্যাচের সারি ──
export function MatchRow({ m, pred, onOpen }) {
  const { lang } = useT();
  const showScore = (isLive(m) || isDone(m)) && m.home_score != null;
  const hw = isDone(m) && m.home_score > m.away_score, aw = isDone(m) && m.away_score > m.home_score;
  return (
    <button className="row" onClick={() => onOpen?.(m)}>
      <div className={"side home" + (hw ? " win" : "")}>
        <span>{teamName(m.home, lang)}</span>
        <Crest team={m.home} />
      </div>
      <div className="mid">
        {showScore ? (
          <div className="sc">{num(m.home_score, lang)} - {num(m.away_score, lang)}</div>
        ) : (
          <div className="t" style={isOff(m) ? { textDecoration: "line-through", opacity: 0.6 } : null}>{timeLabel(m.utc_date, lang)}</div>
        )}
        <div className="st"><StatusText m={m} /></div>
        {pred && (
          <span className="pred-tag">
            🎯 {num(pred.home, lang)}-{num(pred.away, lang)}
            {pred.points != null && ` · +${num(pred.points, lang)}`}
          </span>
        )}
      </div>
      <div className={"side" + (aw ? " win" : "")}>
        <Crest team={m.away} />
        <span>{teamName(m.away, lang)}</span>
      </div>
    </button>
  );
}

// ── প্রতিযোগিতা অনুযায়ী ভাগ করা তালিকা ──
export function CompGroups({ matches, preds = {}, onOpen }) {
  const { lang } = useT();
  const groups = [];
  const idx = {};
  for (const m of matches) {
    const k = m.competition_code;
    if (!(k in idx)) { idx[k] = groups.length; groups.push({ c: m.competition, list: [] }); }
    groups[idx[k]].list.push(m);
  }
  groups.sort((a, b) => (a.c?.sort ?? 99) - (b.c?.sort ?? 99));
  return groups.map((g) => (
    <div className="card" style={{ marginBottom: 10 }} key={g.c?.code || "x"}>
      <div className="comp-h"><CompIcon c={g.c} />{compName(g.c, lang)}</div>
      {g.list.map((m) => <MatchRow key={m.id} m={m} pred={preds[m.id]} onOpen={onOpen} />)}
    </div>
  ));
}

// ── প্রতি মিনিটে রেন্ডার (কাউন্টডাউনের জন্য) ──
export function useNow(ms = 30000) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const i = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(i); }, [ms]);
  return now;
}

// ── শেয়ার ──
export function shareText(m, lang) {
  const day = dayLabel(dayKey(m.utc_date), lang, { short: false });
  if (lang === "bn")
    return `⚽ ${teamName(m.home, "bn")} বনাম ${teamName(m.away, "bn")}\n🏆 ${compName(m.competition, "bn")}\n🗓 ${day}\n⏰ ${timeLabel(m.utc_date, "bn")} (বাংলাদেশ সময়)\n\nখেলা কখন? → khelakokhon.com`;
  return `⚽ ${teamName(m.home, "en")} vs ${teamName(m.away, "en")}\n🏆 ${compName(m.competition, "en")}\n🗓 ${day}\n⏰ ${timeLabel(m.utc_date, "en")} (Bangladesh time)\n\nkhelakokhon.com`;
}

export async function shareMatch(m, lang, toast) {
  const text = shareText(m, lang);
  try {
    if (navigator.share) { await navigator.share({ text }); return; }
  } catch (e) { if (e?.name === "AbortError") return; }
  try { await navigator.clipboard.writeText(text); toast?.(lang === "bn" ? "কপি হয়েছে — যেখানে খুশি পেস্ট করো" : "Copied"); } catch { /* ignore */ }
}

function Stepper({ v, set }) {
  return (
    <div className="stepper">
      <button onClick={() => set(Math.max(0, v - 1))} aria-label="-">−</button>
      <div className="v">{v}</div>
      <button onClick={() => set(Math.min(20, v + 1))} aria-label="+">+</button>
    </div>
  );
}

// ── ম্যাচের বিস্তারিত (নিচ থেকে ওঠা শিট) ──
export function MatchSheet({ m, user, pred, onClose, onSave, onLogin, toast }) {
  const { t, lang } = useT();
  const now = useNow(1000 * 20);
  const [h, setH] = useState(pred?.home ?? 1);
  const [a, setA] = useState(pred?.away ?? 1);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const open = canPredict(m);
  const showScore = (isLive(m) || isDone(m)) && m.home_score != null;

  async function save() {
    setBusy(true); setErr("");
    try { await onSave(m, h, a); toast(t("saved")); onClose(); }
    catch (e) { setErr(e?.message || t("error")); }
    setBusy(false);
  }

  return (
    <div className="veil" onClick={onClose}>
      <div className="sheet" onClick={(e) => e.stopPropagation()}>
        <div className="grab" />
        <div className="hero" style={{ boxShadow: "none" }}>
          <div className="hero-top"><CompIcon c={m.competition} size={16} />{compName(m.competition, lang)}
            {m.matchday ? <> · {t("matchday")} {num(m.matchday, lang)}</> : null}</div>
          <div className="hero-teams">
            <div className="hero-team"><Crest team={m.home} size={56} />{teamName(m.home, lang)}</div>
            <div className="hero-vs">
              {showScore ? <div style={{ fontFamily: "Inter", fontSize: 30, fontWeight: 800, opacity: 1 }}>{num(m.home_score, lang)} - {num(m.away_score, lang)}</div> : t("vs")}
              <div style={{ fontSize: 12, marginTop: 4 }}><StatusText m={m} /></div>
            </div>
            <div className="hero-team"><Crest team={m.away} size={56} />{teamName(m.away, lang)}</div>
          </div>
          <div className="hero-time">
            <div className="big">{timeLabel(m.utc_date, lang)}</div>
            <div className="when">{dayLabel(dayKey(m.utc_date), lang)} · {t("bdTime")}</div>
          </div>
          {open && (
            <div className="cd"><span>{t("startsIn")} <b>{countdown(new Date(m.utc_date) - now, lang)}</b></span></div>
          )}
        </div>

        <div className="sec" style={{ margin: "16px 0 0" }}>
          <div className="sec-h"><h2>{t("yourPick")}</h2>
            {pred?.points != null && <span className={"ptbadge p" + pred.points}>+{num(pred.points, lang)} {t("pts")}</span>}</div>
          {!user ? (
            <button className="btn ghost block" onClick={onLogin}>{t("loginToPredict")}</button>
          ) : open ? (
            <div className="card">
              <div className="pred-box">
                <Stepper v={h} set={setH} />
                <div className="dash">–</div>
                <Stepper v={a} set={setA} />
              </div>
              <div style={{ padding: "0 12px 12px" }}>
                {err && <div className="err">{err}</div>}
                <button className="btn block" disabled={busy} onClick={save}>{busy ? "…" : t("save")}</button>
              </div>
            </div>
          ) : (
            <div className="card empty">
              {pred ? <b style={{ fontSize: 18, color: "var(--text)" }}>{num(pred.home, lang)} – {num(pred.away, lang)}</b> : null}
              <div style={{ marginTop: pred ? 6 : 0 }}>{t("locked")}</div>
            </div>
          )}
        </div>

        <button className="btn ghost block" style={{ marginTop: 12 }} onClick={() => shareMatch(m, lang, toast)}>
          <ShareIcon /> {t("share")}
        </button>
      </div>
    </div>
  );
}

// ── আইকন ──
const I = (d) => (p) => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}>{d}</svg>
);
export const HomeIcon = I(<><path d="M3 10.5 12 3l9 7.5" /><path d="M5 9.5V21h14V9.5" /><path d="M10 21v-6h4v6" /></>);
export const BallIcon = I(<><circle cx="12" cy="12" r="9" /><path d="m12 7 4 3-1.5 4.5h-5L8 10z" /><path d="M12 3v4M21 10.5l-5-.5M18 19l-3.5-4.5M6 19l3.5-4.5M3 10.5l5-.5" /></>);
export const TargetIcon = I(<><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></>);
export const UserIcon = I(<><circle cx="12" cy="8" r="4" /><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" /></>);
export const ShareIcon = I(<><circle cx="18" cy="5" r="3" /><circle cx="6" cy="12" r="3" /><circle cx="18" cy="19" r="3" /><path d="m8.6 13.5 6.8 4M15.4 6.5l-6.8 4" /></>);
export const SunIcon = I(<><circle cx="12" cy="12" r="4" /><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4" /></>);
export const MoonIcon = I(<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />);
